package com.jetblue.cobrand.service.impl;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.jetblue.cobrand.service.BarclaysEncryptionService;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jwt.JWTClaimsSet;

@Service
public class BarclaysEncryptionServiceImpl implements BarclaysEncryptionService {
	
	SecretKey contentEncryptKey;
	private static final Logger log = LoggerFactory.getLogger(BarclaysEncryptionServiceImpl.class);

	@Override
	public String encrypt(String xmlPayloadString) {	
		Resource publicKeyResource = getPemFile("classpath:keys/public-key.pem");

		// Generate random Content Encryption Key(CEK)
		KeyGenerator keyGen;
		try {
			keyGen = KeyGenerator.getInstance("AES");
			keyGen.init(256);
			contentEncryptKey = keyGen.generateKey();
		} catch (NoSuchAlgorithmException e) {
			log.error("Error while Generating Key using Algorithm : {} ", e.getMessage());
		}

		JWEHeader jweHeader = new JWEHeader.Builder(JWEAlgorithm.parse("RSA-OAEP-256"),
				EncryptionMethod.parse("A256GCM")).keyID("{private-key-reference or key-id").contentType("BASE64")
				.customParam("uuid", UUID.randomUUID()).build();

		JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
				.issueTime(new Date())
				.issuer("pcs-barclaysus.com")
				.jwtID(UUID.randomUUID().toString())				
				.claim("content-type", "BASE64")
				.claim("content", xmlPayloadString)
				.build();

		Payload payload = new Payload(claimsSet.toJSONObject());
		JWEObject jweEncrptionObj = new JWEObject(jweHeader, payload);
		try {
			jweEncrptionObj.encrypt(new RSAEncrypter(getPublicKeyFromPem(publicKeyResource.getFile()), contentEncryptKey));
		} catch (Exception e) {
			log.error("Error while Encrypting the given payload : {} ", e.getMessage());
		}
		String encryptedJwt = jweEncrptionObj.serialize();
		log.info("Encrypted JWT String:: {} ", encryptedJwt);
		return encryptedJwt;
	}

	
	private static Resource getPemFile(String filePath) {
		ResourceLoader resourceLoader = new DefaultResourceLoader();
		return resourceLoader.getResource(filePath);
	}
	
	public static RSAPublicKey getPublicKeyFromPem(File file) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		String key = new String(Files.readAllBytes(file.toPath()));

		String publicKeyPEM = key.replace("-----BEGIN PUBLIC KEY-----", "").replaceAll(System.lineSeparator(), "")
				.replace("-----END PUBLIC KEY-----", "");

		byte[] encodedBytes = Base64.getDecoder().decode(publicKeyPEM);

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encodedBytes);
		return (RSAPublicKey) keyFactory.generatePublic(keySpec);
	}

}
