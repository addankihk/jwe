package com.jetblue.cobrand.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.ParseException;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.jetblue.cobrand.service.BarclaysDecryptionService;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.crypto.RSADecrypter;

@Service
public class BarclaysDecryptionServiceImpl implements BarclaysDecryptionService {
	
	private static final Logger log = LoggerFactory.getLogger(BarclaysDecryptionServiceImpl.class);

	@Override
	public String decrypt(String encryptedJwt) {
		 JWEObject jweDecrptionObj = null;
		try {
			jweDecrptionObj = JWEObject.parse(encryptedJwt);
			
			 Resource privateKeyResource = getPemFile("classpath:keys/enckey.pem");
			 
			 jweDecrptionObj.decrypt(new RSADecrypter(getPirvateKeyFromPem(privateKeyResource.getFile())));
			 jweDecrptionObj.getPayload().toString();
			  
			  log.info("Decrypted Payload (W/ Meta Data) :: {} ", jweDecrptionObj.getPayload());

			  log.info("Decrypted Payload (ONLY CONTENT) :: {} " , jweDecrptionObj.getPayload().toJSONObject().get("content"));
			  
			  return (String) jweDecrptionObj.getPayload().toJSONObject().get("content");
		}
		catch (JOSEException | ParseException | IOException | NoSuchAlgorithmException | InvalidKeySpecException e) {
			log.error("Error while Encrypting the given payload : {} ", e.getMessage());
		} 
		return null;
		 
	}

	
	private static Resource getPemFile(String filePath) {
		ResourceLoader resourceLoader = new DefaultResourceLoader();
		return resourceLoader.getResource(filePath);
	}
	
	public static PrivateKey getPirvateKeyFromPem(File file) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		String key = new String(Files.readAllBytes(file.toPath()));

	    String privateKeyPEM = key
	      .replace("-----BEGIN PRIVATE KEY-----", "")
	      .replaceAll(System.lineSeparator(), "")
	      .replace("-----END PRIVATE KEY-----", "");

	    byte[] encodedBytes = Base64.getDecoder().decode(privateKeyPEM);	 
	   
	    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encodedBytes);
	    KeyFactory keyFactory;
		keyFactory = KeyFactory.getInstance("RSA");
	    return keyFactory.generatePrivate(keySpec);	    
	}
}
