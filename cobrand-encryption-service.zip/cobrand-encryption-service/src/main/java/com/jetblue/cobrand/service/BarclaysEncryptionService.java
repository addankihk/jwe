package com.jetblue.cobrand.service;

public interface BarclaysEncryptionService {
	
	public String encrypt(String content);

}
