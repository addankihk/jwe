package com.jetblue.cobrand.service;

public interface BarclaysDecryptionService {
	
	public String decrypt(String encryptedString);

}
