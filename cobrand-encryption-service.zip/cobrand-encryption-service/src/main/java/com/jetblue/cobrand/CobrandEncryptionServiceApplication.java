package com.jetblue.cobrand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CobrandEncryptionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CobrandEncryptionServiceApplication.class, args);
	}

}
