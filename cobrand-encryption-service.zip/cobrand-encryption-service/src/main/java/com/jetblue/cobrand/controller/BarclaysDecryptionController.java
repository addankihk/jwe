package com.jetblue.cobrand.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jetblue.cobrand.service.BarclaysDecryptionService;

@RestController
@RequestMapping(path = "/barclays")
public class BarclaysDecryptionController {
	
	@Autowired
	BarclaysDecryptionService barclaysDecryptionService;
	
	@PostMapping(path = "/decryption", produces = {"application/xml", "application/json"})
	public ResponseEntity<String> decryptContent(@RequestBody String encryptedJWT) {
		
		return ResponseEntity.ok(barclaysDecryptionService.decrypt(encryptedJWT));
	}
}
