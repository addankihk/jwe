package com.jetblue.cobrand.cobrandencryptionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CobrandEncryptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
